# To-Do List — Full Stack (DecodeLabs Project 1)

A complete To-Do List application built as a natural extension of the
Project 1 brief: add tasks, view them, and — going beyond the base
requirement — mark them done, delete them, persist them to disk, and
serve them through a real HTTP API to a browser frontend.

```
todo-app/
├── backend/
│   ├── app.py                  # Flask API (View/Controller — HTTP boundary)
│   ├── task_manager.py         # Model — data logic, in-memory + JSON persistence
│   ├── requirements.txt
│   └── tests/
│       ├── test_task_manager.py  # unit tests (model layer, 18 cases)
│       └── test_app.py           # integration tests (HTTP layer, 10 cases)
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js                # ApiClient + DOM rendering
└── README.md
```

## Architecture

This follows the Model/View split from the training kit's "Decoupling
the Architecture" slide:

- **Model** (`task_manager.py`): a `TaskManager` class owning a list of
  `Task` dataclass instances (dict → table row). It knows nothing about
  HTTP or the DOM — it could just as easily back a CLI or desktop app.
- **API Boundary** (`app.py`): a thin Flask layer translating HTTP verbs
  into Model calls and Model results into JSON + status codes.
- **View** (`frontend/`): a static HTML/CSS/JS app that talks to the API
  through a single `ApiClient` object — no scattered `fetch()` calls.
- **Persistence**: every mutation writes to `backend/tasks.json` via an
  atomic write (`os.replace` after writing to a temp file), addressing
  the "Volatile Trap" slide — RAM state survives a process restart.

## Setup & Run

Everything — API and frontend — runs from **one command, one port**.
Flask serves the static frontend files directly, so there's no second
server to start and no CORS issues to worry about.

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open **`http://127.0.0.1:5000`** in your browser — that's the app.

Verify the API directly if needed:

```bash
curl http://127.0.0.1:5000/api/health
```

> **Note:** Visiting `http://127.0.0.1:5000/` used to 404 in an earlier
> version of this project, because Flask only defined `/api/*` routes
> and the frontend files lived in a separate folder Flask never served.
> `app.py` now sets `static_folder` to `../frontend` and adds a `/`
> route returning `index.html`, so the root URL serves the UI directly.

### API Reference

| Method | Endpoint                  | Body                  | Description               |
|--------|----------------------------|-----------------------|----------------------------|
| GET    | `/api/tasks`               | —                     | List all tasks             |
| POST   | `/api/tasks`                | `{"description": str}` | Create a task              |
| PATCH  | `/api/tasks/<id>/done`      | `{"done": bool}`      | Mark task done/undone      |
| DELETE | `/api/tasks/<id>`           | —                     | Delete a task               |
| GET    | `/api/health`                | —                     | Health check                |

## Running Tests

```bash
cd backend
pip install -r requirements.txt   # includes pytest
python -m pytest tests/ -v
```

**Current status: 28/28 tests passing** (18 model unit tests, 10 API
integration tests) — verified prior to packaging this project.

---

## Root Cause Analysis — Issues Found & Fixed During Build

| Issue | Root Cause | Fix |
|---|---|---|
| Concurrent writes could corrupt `tasks.json` | Flask's dev server is multi-threaded; two requests mutating the list simultaneously is a race condition | Added a `threading.Lock` around every mutating method in `TaskManager` |
| A crashed write could leave `tasks.json` half-written | `json.dump` writes directly to the target file; a crash mid-write truncates it | Write to a `.tmp` file first, then `os.replace()` — atomic on POSIX and Windows |
| A hand-edited or corrupted `tasks.json` would crash the app on startup | `load()` assumed well-formed JSON matching the `Task` schema | Wrapped load in `try/except` for `JSONDecodeError`/`TypeError`/`KeyError`, falling back to an empty task list instead of crashing |
| IDs could collide after deleting the highest-id task and reloading | Naive "next id = len(tasks) + 1" reuses ids after deletion | `_next_id` is tracked explicitly and recomputed on load as `max(existing ids) + 1`, never derived from list length |
| `GET /` returned 404 when running `python app.py` | Flask only had `/api/*` routes; the frontend lived in a separate folder Flask never served, so users expecting a single-URL app hit an undefined route | Configured Flask's `static_folder` to point at `../frontend` with `static_url_path=""`, and added a `/` route returning `index.html` — one process now serves both API and UI |

## Prevention — How to Avoid Similar Bugs Going Forward

1. **Concurrency**: any shared mutable state accessed from multiple
   request threads needs an explicit lock (or a switch to a real
   database with transactional guarantees — SQLite would remove the
   need for the lock entirely). Add a load test (e.g. `locust` or a
   simple threaded script hammering `POST /api/tasks`) to catch races
   before they reach production.
2. **Non-atomic file writes**: never write directly to a file that
   must remain valid between requests. Standardize on the
   write-temp-then-replace pattern for all file persistence in this
   codebase, or move to a proper database once task volume grows.
3. **Untrusted input on load**: any time you deserialize data you
   didn't just serialize yourself (including your own JSON file after
   a manual edit or partial write), validate defensively. Consider a
   schema validation library (`pydantic`) if the data model grows past
   a few fields.
4. **ID generation**: never derive an ID from a collection's current
   size. Use an explicit monotonically increasing counter (as done
   here) or a UUID.

## Next Steps

- **Database migration**: swap the JSON file for SQLite (`sqlite3` or
  SQLAlchemy) once multi-user access or task history is needed — the
  `TaskManager` interface wouldn't need to change, only its internals.
- **Authentication**: add per-user task lists (currently a single
  shared list) via session tokens or JWT.
- **Input validation hardening**: add a max-tasks-per-user limit and
  rate limiting (`flask-limiter`) to the `POST /api/tasks` endpoint to
  prevent abuse.
- **Frontend polish**: add optimistic UI updates (update the DOM before
  the API response returns, roll back on error) to remove the small
  latency delay on each action.
- **CI**: wire `pytest` into a GitHub Actions workflow so the test
  suite runs on every push/PR automatically.
- **Production deployment**: replace `app.run(debug=True)` with a WSGI
  server (`gunicorn`/`waitress`) behind a reverse proxy, and disable
  Flask debug mode entirely outside local development.
