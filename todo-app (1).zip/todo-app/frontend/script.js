const API = "/api";

const form = document.getElementById("task-form");
const input = document.getElementById("task-input");
const list = document.getElementById("task-list");
const emptyState = document.getElementById("empty-state");
const errorBanner = document.getElementById("error-banner");
const taskCount = document.getElementById("task-count");

function flashError(msg) {
  errorBanner.textContent = msg;
  errorBanner.hidden = false;
  setTimeout(() => (errorBanner.hidden = true), 4000);
}

async function api(path, opts = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || "Something went wrong.");
  return body;
}

function renderTasks(tasks) {
  list.innerHTML = "";
  emptyState.hidden = tasks.length > 0;

  for (const task of tasks) {
    const li = document.createElement("li");
    li.className = `task-item${task.done ? " task-item--done" : ""}`;

    const checkbox = Object.assign(document.createElement("input"), {
      type: "checkbox",
      className: "task-item__checkbox",
      checked: task.done,
    });
    checkbox.onchange = () => toggleDone(task.id, checkbox.checked);

    const text = document.createElement("span");
    text.className = "task-item__text";
    text.textContent = task.description;

    const del = document.createElement("button");
    del.className = "task-item__delete";
    del.textContent = "✕";
    del.onclick = () => removeTask(task.id);

    li.append(checkbox, text, del);
    list.appendChild(li);
  }

  const done = tasks.filter((t) => t.done).length;
  taskCount.textContent = `${tasks.length} task${tasks.length === 1 ? "" : "s"} · ${done} done`;
}

async function refresh() {
  try {
    renderTasks(await api("/tasks"));
  } catch (err) {
    flashError(err.message);
  }
}

async function addTask(description) {
  try {
    await api("/tasks", { method: "POST", body: JSON.stringify({ description }) });
    refresh();
  } catch (err) {
    flashError(err.message);
  }
}

async function toggleDone(id, done) {
  try {
    await api(`/tasks/${id}/done`, { method: "PATCH", body: JSON.stringify({ done }) });
    refresh();
  } catch (err) {
    flashError(err.message);
    refresh();
  }
}

async function removeTask(id) {
  try {
    await api(`/tasks/${id}`, { method: "DELETE" });
    refresh();
  } catch (err) {
    flashError(err.message);
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const description = input.value.trim();
  if (!description) return;
  input.value = "";
  addTask(description);
});

refresh();
