import os
from dataclasses import asdict

from flask import Flask, jsonify, request
from flask_cors import CORS

from task_manager import TaskManager

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)

manager = TaskManager()


@app.get("/")
def index():
    return app.send_static_file("index.html")


@app.get("/api/tasks")
def list_tasks():
    tasks = manager.view_tasks()
    return jsonify([asdict(t) for t in tasks])


@app.post("/api/tasks")
def create_task():
    data = request.get_json(silent=True) or {}
    try:
        task = manager.add_task(data.get("description", ""))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(asdict(task)), 201


@app.patch("/api/tasks/<int:task_id>/done")
def mark_task_done(task_id):
    data = request.get_json(silent=True) or {}
    task = manager.mark_done(task_id, bool(data.get("done", True)))
    if not task:
        return jsonify({"error": f"Task {task_id} not found"}), 404
    return jsonify(asdict(task))


@app.delete("/api/tasks/<int:task_id>")
def delete_task(task_id):
    if not manager.remove_task(task_id):
        return jsonify({"error": f"Task {task_id} not found"}), 404
    return jsonify({"status": "deleted", "id": task_id})


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


@app.errorhandler(404)
def not_found(_e):
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def server_error(_e):
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    # debug reloader is handy locally but this should never run in prod like this
    app.run(host="0.0.0.0", port=5000, debug=True)
