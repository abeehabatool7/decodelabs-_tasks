import json
import os
import threading
from dataclasses import dataclass, asdict
from typing import List, Optional

DATA_FILE = os.path.join(os.path.dirname(__file__), "tasks.json")


@dataclass
class Task:
    id: int
    description: str
    done: bool = False


class TaskManager:
    def __init__(self, storage_path: str = DATA_FILE) -> None:
        self._storage_path = storage_path
        self._tasks: List[Task] = []
        self._next_id = 1
        self._lock = threading.Lock()
        self.load()

    def add_task(self, description: str) -> Task:
        description = (description or "").strip()
        if not description:
            raise ValueError("Task description cannot be empty.")
        if len(description) > 280:
            raise ValueError("Task description cannot exceed 280 characters.")

        with self._lock:
            task = Task(id=self._next_id, description=description)
            self._tasks.append(task)
            self._next_id += 1
            self._save_locked()
            return task

    def view_tasks(self) -> List[Task]:
        with self._lock:
            return list(self._tasks)

    def get_task(self, task_id: int) -> Optional[Task]:
        with self._lock:
            return next((t for t in self._tasks if t.id == task_id), None)

    def mark_done(self, task_id: int, done: bool = True) -> Optional[Task]:
        with self._lock:
            task = next((t for t in self._tasks if t.id == task_id), None)
            if not task:
                return None
            task.done = done
            self._save_locked()
            return task

    def remove_task(self, task_id: int) -> bool:
        with self._lock:
            task = next((t for t in self._tasks if t.id == task_id), None)
            if not task:
                return False
            self._tasks.remove(task)
            self._save_locked()
            return True

    def _save_locked(self) -> None:
        # write to a temp file first - don't want a crash mid-write nuking the real data
        tmp_path = f"{self._storage_path}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump([asdict(t) for t in self._tasks], f, indent=2)
        os.replace(tmp_path, self._storage_path)

    def save(self) -> None:
        with self._lock:
            self._save_locked()

    def load(self) -> None:
        if not os.path.exists(self._storage_path):
            return

        with self._lock:
            try:
                with open(self._storage_path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                self._tasks = [Task(**item) for item in raw]
                self._next_id = max((t.id for t in self._tasks), default=0) + 1
            except (json.JSONDecodeError, TypeError, KeyError):
                # someone hand-edited the file or it got clipped mid-write, whatever - don't die on it
                self._tasks = []
                self._next_id = 1
