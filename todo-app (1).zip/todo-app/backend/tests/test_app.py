import os
import sys
import importlib

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


@pytest.fixture
def client(tmp_path):
    """
    Reload the app module and inject an isolated storage file so tests
    never touch the real tasks.json used by the running dev server.
    """
    storage_path = str(tmp_path / "tasks.json")

    import task_manager
    import app as app_module
    importlib.reload(task_manager)
    importlib.reload(app_module)
    app_module.manager = task_manager.TaskManager(storage_path=storage_path)

    app_module.app.config["TESTING"] = True
    with app_module.app.test_client() as c:
        yield c


def test_health(client):
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.get_json() == {"status": "ok"}


def test_list_tasks_empty(client):
    resp = client.get("/api/tasks")
    assert resp.status_code == 200
    assert resp.get_json() == []


def test_create_task(client):
    resp = client.post("/api/tasks", json={"description": "Finish Python assignment"})
    assert resp.status_code == 201
    body = resp.get_json()
    assert body["description"] == "Finish Python assignment"
    assert body["done"] is False
    assert "id" in body


def test_create_task_missing_description(client):
    resp = client.post("/api/tasks", json={})
    assert resp.status_code == 400
    assert "error" in resp.get_json()


def test_create_task_empty_description(client):
    resp = client.post("/api/tasks", json={"description": "   "})
    assert resp.status_code == 400


def test_mark_task_done(client):
    create = client.post("/api/tasks", json={"description": "A"})
    task_id = create.get_json()["id"]

    resp = client.patch(f"/api/tasks/{task_id}/done", json={"done": True})
    assert resp.status_code == 200
    assert resp.get_json()["done"] is True


def test_mark_task_done_not_found(client):
    resp = client.patch("/api/tasks/999/done", json={"done": True})
    assert resp.status_code == 404


def test_delete_task(client):
    create = client.post("/api/tasks", json={"description": "A"})
    task_id = create.get_json()["id"]

    resp = client.delete(f"/api/tasks/{task_id}")
    assert resp.status_code == 200

    listing = client.get("/api/tasks")
    assert listing.get_json() == []


def test_delete_task_not_found(client):
    resp = client.delete("/api/tasks/999")
    assert resp.status_code == 404


def test_404_on_unknown_route(client):
    resp = client.get("/api/nonexistent")
    assert resp.status_code == 404
    assert "error" in resp.get_json()
