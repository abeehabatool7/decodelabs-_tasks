import os
import sys
import json
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from task_manager import TaskManager  # noqa: E402


@pytest.fixture
def manager(tmp_path):
    """Fresh TaskManager backed by a temp file for each test (test isolation)."""
    storage_path = tmp_path / "tasks.json"
    return TaskManager(storage_path=str(storage_path))


# ---- add_task ----

def test_add_task_success(manager):
    task = manager.add_task("Buy milk")
    assert task.id == 1
    assert task.description == "Buy milk"
    assert task.done is False


def test_add_task_empty_string_raises(manager):
    with pytest.raises(ValueError):
        manager.add_task("")


def test_add_task_whitespace_only_raises(manager):
    with pytest.raises(ValueError):
        manager.add_task("   ")


def test_add_task_none_raises(manager):
    with pytest.raises(ValueError):
        manager.add_task(None)


def test_add_task_too_long_raises(manager):
    with pytest.raises(ValueError):
        manager.add_task("x" * 281)


def test_add_task_strips_whitespace(manager):
    task = manager.add_task("  Walk dog  ")
    assert task.description == "Walk dog"


def test_ids_increment_and_do_not_reuse_after_delete(manager):
    t1 = manager.add_task("A")
    t2 = manager.add_task("B")
    manager.remove_task(t1.id)
    t3 = manager.add_task("C")
    assert t3.id == t2.id + 1  # id counter never reuses a deleted id


# ---- view_tasks ----

def test_view_tasks_empty_initially(manager):
    assert manager.view_tasks() == []


def test_view_tasks_returns_copy_not_internal_list(manager):
    manager.add_task("A")
    tasks = manager.view_tasks()
    tasks.clear()
    assert len(manager.view_tasks()) == 1  # internal state untouched


# ---- mark_done ----

def test_mark_done_existing_task(manager):
    task = manager.add_task("A")
    updated = manager.mark_done(task.id)
    assert updated.done is True


def test_mark_done_nonexistent_task_returns_none(manager):
    assert manager.mark_done(999) is None


def test_mark_done_can_be_toggled_false(manager):
    task = manager.add_task("A")
    manager.mark_done(task.id, True)
    updated = manager.mark_done(task.id, False)
    assert updated.done is False


# ---- remove_task ----

def test_remove_existing_task(manager):
    task = manager.add_task("A")
    assert manager.remove_task(task.id) is True
    assert manager.view_tasks() == []


def test_remove_nonexistent_task_returns_false(manager):
    assert manager.remove_task(999) is False


# ---- persistence ----

def test_save_and_load_round_trip(tmp_path):
    storage_path = str(tmp_path / "tasks.json")
    m1 = TaskManager(storage_path=storage_path)
    m1.add_task("Persisted task")

    m2 = TaskManager(storage_path=storage_path)  # loads on init
    tasks = m2.view_tasks()
    assert len(tasks) == 1
    assert tasks[0].description == "Persisted task"


def test_load_handles_corrupted_file_gracefully(tmp_path):
    storage_path = tmp_path / "tasks.json"
    storage_path.write_text("{not valid json")
    manager = TaskManager(storage_path=str(storage_path))
    assert manager.view_tasks() == []  # falls back to empty state, no crash


def test_load_handles_missing_file(tmp_path):
    storage_path = tmp_path / "does_not_exist.json"
    manager = TaskManager(storage_path=str(storage_path))
    assert manager.view_tasks() == []


def test_next_id_recovers_correctly_after_reload(tmp_path):
    storage_path = str(tmp_path / "tasks.json")
    m1 = TaskManager(storage_path=storage_path)
    m1.add_task("A")
    m1.add_task("B")

    m2 = TaskManager(storage_path=storage_path)
    new_task = m2.add_task("C")
    assert new_task.id == 3
